@extends('layouts.app')

@section('content')
    <!-- About Hero Section -->
    <section class="about-hero-modern">
        <div class="hero-video-background">
            <video autoplay muted loop playsinline class="hero-bg-video">
                <source src="{{ asset('videos/about-hero.mp4') }}" type="video/mp4">
            </video>
            <div class="video-overlay"></div>
        </div>
        <div class="particles-bg"></div>
        <div class="hero-gradient"></div>
        
        <div class="about-hero-content" data-aos="fade-up">
            <div class="hero-badge">
                <span class="badge-dot"></span>
                {{ __('about.hero.badge') }}
            </div>
            <h1 class="hero-heading">
                {!! __('about.hero.title') !!}
            </h1>
            <p class="hero-description">
                {{ __('about.hero.description') }}
            </p>
        </div>
    </section>

    <!-- Our Story Section -->
    <section class="story-section">
        <div class="story-background">
            <div class="wave-decoration wave-1"></div>
            <div class="wave-decoration wave-2"></div>
            <div class="floating-dots">
                <span class="dot dot-1"></span>
                <span class="dot dot-2"></span>
                <span class="dot dot-3"></span>
                <span class="dot dot-4"></span>
                <span class="dot dot-5"></span>
            </div>
        </div>
        
        <div class="section-container">
            <div class="story-content" data-aos="fade-up">
                <!-- Opening Statement with Visual -->
                <div class="story-hero">
                    <div class="story-hero-visual" data-aos="zoom-in">
                        <div class="ocean-icon">
                            <svg width="120" height="120" viewBox="0 0 120 120" fill="none">
                                <circle cx="60" cy="60" r="50" stroke="#0284C7" stroke-width="2" opacity="0.2"/>
                                <circle cx="60" cy="60" r="40" stroke="#0284C7" stroke-width="2" opacity="0.4"/>
                                <circle cx="60" cy="60" r="30" stroke="#0284C7" stroke-width="2" opacity="0.6"/>
                                <path d="M30 60C30 43.4315 43.4315 30 60 30C76.5685 30 90 43.4315 90 60" stroke="url(#oceanGradient)" stroke-width="3" stroke-linecap="round"/>
                                <circle cx="60" cy="60" r="15" fill="url(#oceanGradient)"/>
                                <defs>
                                    <linearGradient id="oceanGradient" x1="30" y1="30" x2="90" y2="90">
                                        <stop offset="0%" stop-color="#0284C7"/>
                                        <stop offset="100%" stop-color="#0369A1"/>
                                    </linearGradient>
                                </defs>
                            </svg>
                        </div>
                    </div>
                    <div class="story-hero-text">
                        <h2 class="story-lead-title" data-aos="fade-up">{{ __('about.story.lead_title') }}</h2>
                        <p class="story-statement" data-aos="fade-up" data-aos-delay="100">
                            <span class="highlight-blue">{{ __('about.story.statement') }}</span>
                        </p>
                    </div>
                </div>

                <!-- Timeline Section -->
                <div class="story-timeline" data-aos="fade-up" data-aos-delay="200">
                    <div class="timeline-header">
                        <div class="timeline-badge">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <circle cx="12" cy="12" r="10" stroke="#0284C7" stroke-width="2"/>
                                <path d="M12 6V12L16 14" stroke="#0284C7" stroke-width="2" stroke-linecap="round"/>
                            </svg>
                            <span>{{ __('about.ui.a_decade_ago') }}</span>
                        </div>
                    </div>
                    
                    <p class="timeline-text" data-aos="fade-up" data-aos-delay="250">
                        {{ __('about.story.timeline_text') }}
                    </p>
                    
                    <div class="challenges-grid">
                        <div class="challenge-card" data-aos="flip-left" data-aos-delay="300">
                            <div class="challenge-icon">
                                <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                                    <path d="M10 20L14 16M14 16L10 12M14 16H6M30 20L26 24M26 24L30 28M26 24H34M20 10L24 14M24 14L28 10M24 14V6M20 30L16 26M16 26L12 30M16 26V34" stroke="#0284C7" stroke-width="2" stroke-linecap="round"/>
                                    <circle cx="20" cy="20" r="3" fill="#0284C7"/>
                                </svg>
                            </div>
                            <h4>{{ __('about.story.challenges.0.title') }}</h4>
                            <p>{{ __('about.story.challenges.0.description') }}</p>
                        </div>
                        
                        <div class="challenge-card" data-aos="flip-left" data-aos-delay="350">
                            <div class="challenge-icon">
                                <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                                    <rect x="6" y="6" width="12" height="12" rx="2" stroke="#0284C7" stroke-width="2"/>
                                    <rect x="22" y="6" width="12" height="12" rx="2" stroke="#0284C7" stroke-width="2"/>
                                    <rect x="6" y="22" width="12" height="12" rx="2" stroke="#0284C7" stroke-width="2"/>
                                    <rect x="22" y="22" width="12" height="12" rx="2" stroke="#0284C7" stroke-width="2"/>
                                    <path d="M18 12H22M12 18V22M28 18V22M18 28H22" stroke="#0284C7" stroke-width="2" stroke-dasharray="2 2"/>
                                </svg>
                            </div>
                            <h4>{{ __('about.story.challenges.1.title') }}</h4>
                            <p>{{ __('about.story.challenges.1.description') }}</p>
                        </div>
                        
                        <div class="challenge-card" data-aos="flip-left" data-aos-delay="400">
                            <div class="challenge-icon">
                                <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                                    <rect x="8" y="8" width="24" height="24" rx="3" stroke="#0284C7" stroke-width="2"/>
                                    <path d="M14 20L18 24L26 16" stroke="#0284C7" stroke-width="2" stroke-linecap="round"/>
                                    <path d="M18 24L14 28" stroke="#0284C7" stroke-width="2" stroke-linecap="round"/>
                                    <circle cx="28" cy="28" r="3" stroke="#0284C7" stroke-width="2"/>
                                    <line x1="25" y1="25" x2="22" y2="22" stroke="#0284C7" stroke-width="2"/>
                                </svg>
                            </div>
                            <h4>{{ __('about.story.challenges.2.title') }}</h4>
                            <p>{{ __('about.story.challenges.2.description') }}</p>
                        </div>
                        
                        <div class="challenge-card" data-aos="flip-left" data-aos-delay="450">
                            <div class="challenge-icon">
                                <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                                    <circle cx="20" cy="20" r="14" stroke="#0284C7" stroke-width="2"/>
                                    <path d="M20 12V20L26 23" stroke="#0284C7" stroke-width="2" stroke-linecap="round"/>
                                    <path d="M12 8L8 12M28 8L32 12M8 28L12 32M28 32L32 28" stroke="#0284C7" stroke-width="2" stroke-linecap="round"/>
                                </svg>
                            </div>
                            <h4>{{ __('about.story.challenges.3.title') }}</h4>
                            <p>{{ __('about.story.challenges.3.description') }}</p>
                        </div>
                    </div>
                </div>

                <!-- Turning Point -->
                <div class="story-pivot" data-aos="zoom-in" data-aos-delay="500">
                    <div class="pivot-content-wrapper">
                        <div class="pivot-text-content">
                            <div class="pivot-icon">
                                <svg width="60" height="60" viewBox="0 0 60 60" fill="none">
                                    <path d="M30 10L35 25L50 30L35 35L30 50L25 35L10 30L25 25L30 10Z" fill="url(#pivotGradient)" stroke="#0284C7" stroke-width="2"/>
                                    <circle cx="30" cy="30" r="8" fill="white"/>
                                    <defs>
                                        <linearGradient id="pivotGradient" x1="10" y1="10" x2="50" y2="50">
                                            <stop offset="0%" stop-color="#0284C7" stop-opacity="0.3"/>
                                            <stop offset="100%" stop-color="#0369A1" stop-opacity="0.6"/>
                                        </linearGradient>
                                    </defs>
                                </svg>
                            </div>
                            <h3 class="pivot-title">{{ __('about.story.pivot_title') }}</h3>
                            <p class="pivot-text">
                                {{ __('about.story.pivot_text') }}
                            </p>
                        </div>
                        <div class="pivot-image" data-aos="fade-left" data-aos-delay="600">
                            <div class="image-wrapper">
                                <img src="{{ asset('images/sbigroup.jpg') }}" alt="SBI Team" class="team-photo">
                                <div class="image-overlay"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 10 Years Journey - Creative Layout -->
                <div class="story-milestone-modern" data-aos="fade-up" data-aos-delay="550">
                    <!-- Top Section: Title + Badge Split -->
                    <div class="milestone-header">
                        <div class="milestone-header-content" data-aos="fade-right" data-aos-delay="575">
                            <span class="milestone-tag">{{ __('about.ui.our_journey') }}</span>
                            <h3>{{ __('about.milestone.title') }}</h3>
                            <p class="milestone-subtitle">{{ __('about.milestone.subtitle') }}</p>
                        </div>
                        <div class="milestone-badge-wrapper" data-aos="zoom-in" data-aos-delay="600">
                            <div class="badge-ring"></div>
                            <div class="badge-ring-2"></div>
                            <div class="year-badge-creative">
                                <span class="year-number">10</span>
                                <span class="year-label">Years</span>
                                <div class="badge-shine"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Intro Text -->
                    <p class="milestone-intro-text" data-aos="fade-up" data-aos-delay="650">
                        {{ __('about.milestone.intro_text') }}
                    </p>

                    <!-- Promise Box - Refined Design -->
                    <div class="promise-box-refined" data-aos="fade-up" data-aos-delay="700">
                        <div class="promise-box-inner">
                            <div class="promise-content-main">
                                <p class="promise-statement-big">
                                    {!! __('about.milestone.promise_statement') !!}
                                </p>
                            </div>
                            <div class="promise-principles">
                                <div class="promise-principle-item">
                                    <div class="promise-principle-icon">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                            <path d="M5 13l4 4L19 7"/>
                                        </svg>
                                    </div>
                                    <span>{{ __('about.ui.no_jargon') }}</span>
                                </div>
                                <div class="promise-principle-divider"></div>
                                <div class="promise-principle-item">
                                    <div class="promise-principle-icon">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                            <path d="M5 13l4 4L19 7"/>
                                        </svg>
                                    </div>
                                    <span>{{ __('about.ui.no_complexity') }}</span>
                                </div>
                                <div class="promise-principle-divider"></div>
                                <div class="promise-principle-item">
                                    <div class="promise-principle-icon">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                            <path d="M5 13l4 4L19 7"/>
                                        </svg>
                                    </div>
                                    <span>{{ __('about.ui.only_solutions') }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="promise-decoration-dots">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                    
                    <!-- Full Width Image Slider -->
                    <div class="milestone-image-creative" data-aos="fade-up" data-aos-delay="750">
                        <div class="about-slider-wrapper">
                            <button class="about-slider-btn about-slider-prev">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M15 18l-6-6 6-6"/>
                                </svg>
                            </button>
                            
                            <div class="about-slider">
                                <div class="about-slider-track">
                                    <div class="about-slide">
                                        <img src="{{ asset('images/sbigroup2.jpg') }}" alt="SBI Team" class="journey-photo-creative">
                                        <div class="image-overlay-gradient"></div>
                                        <div class="image-caption">
                                            <svg class="caption-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                                            </svg>
                                            <p>{{ __('about.ui.anniversary_caption') }}</p>
                                        </div>
                                    </div>
                                    <div class="about-slide">
                                        <img src="{{ asset('images/sbigroup3.jpg') }}" alt="SBI Team" class="journey-photo-creative">
                                        <div class="image-overlay-gradient"></div>
                                        <div class="image-caption">
                                            <svg class="caption-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                                            </svg>
                                            <p></p>
                                        </div>
                                    </div>
                                    <div class="about-slide">
                                        <img src="{{ asset('images/sbigroup4.jpg') }}" alt="SBI Team" class="journey-photo-creative">
                                        <div class="image-overlay-gradient"></div>
                                        <div class="image-caption">
                                            <svg class="caption-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                                            </svg>
                                            <p></p>
                                        </div>
                                    </div>
                                    <div class="about-slide">
                                        <img src="{{ asset('images/sbigroup5.jpg') }}" alt="SBI Team" class="journey-photo-creative">
                                        <div class="image-overlay-gradient"></div>
                                        <div class="image-caption">
                                            <svg class="caption-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                                            </svg>
                                            <p></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="about-slider-dots"></div>
                            </div>
                            
                            <button class="about-slider-btn about-slider-next">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M9 18l6-6-6-6"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Final Statement with Visual Split -->
                <div class="story-closing-modern" data-aos="fade-up" data-aos-delay="700">
                    <div class="closing-visual">
                        <div class="closing-icon-grid">
                            <div class="icon-item" data-aos="zoom-in" data-aos-delay="700">
                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                                    <rect x="4" y="4" width="24" height="24" rx="3" stroke="#0284C7" stroke-width="2"/>
                                    <path d="M10 16L14 20L22 12" stroke="#0284C7" stroke-width="2" stroke-linecap="round"/>
                                </svg>
                                <span>{{ __('about.ui.systems') }}</span>
                            </div>
                            <div class="arrow-divider">→</div>
                            <div class="icon-item" data-aos="zoom-in" data-aos-delay="750">
                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                                    <path d="M6 20L12 14L16 18L26 8" stroke="#0284C7" stroke-width="2" stroke-linecap="round"/>
                                    <circle cx="12" cy="14" r="2" fill="#0284C7"/>
                                    <circle cx="16" cy="18" r="2" fill="#0284C7"/>
                                    <circle cx="26" cy="8" r="2" fill="#0284C7"/>
                                </svg>
                                <span>{{ __('about.ui.growth') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="closing-text">
                        <p class="closing-line">{{ __('about.ui.we_dont_just') }}</p>
                        <p class="closing-statement">
                            <span class="text-gradient-blue">{{ __('about.ui.we_elevate') }}</span>
                        </p>
                        <div class="closing-tags">
                            <span class="tag">{{ __('about.ui.digitally') }}</span>
                            <span class="tag">{{ __('about.ui.operationally') }}</span>
                            <span class="tag">{{ __('about.ui.strategically') }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Vision & Mission -->
    <section class="vm-section-modern">
        <div class="section-container">
            <div class="section-header" data-aos="fade-up">
                <span class="section-tag">{{ __('about.ui.core_values') }}</span>
                <h2 class="section-title">{!! __('about.beliefs.title') !!}</h2>
            </div>

            <div class="vm-grid">
                <div class="vm-card-modern" data-aos="fade-right" data-aos-delay="100">
                    <div class="vm-icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
                            <path d="M24 8L32 16L24 24L16 16L24 8Z" stroke="url(#vmGradient1)" stroke-width="2" fill="rgba(0,229,255,0.1)"/>
                            <circle cx="24" cy="32" r="8" stroke="url(#vmGradient1)" stroke-width="2"/>
                        </svg>
                    </div>
                    <h3 class="vm-title-modern">{{ __('about.beliefs.vision.label') }}</h3>
                    <div class="vision-content-modern">
                        <p class="vision-headline">
                            {{ __('about.beliefs.vision.headline') }}
                        </p>
                        <p class="vision-description">
                            {{ __('about.beliefs.vision.description') }}
                        </p>
                    </div>
                </div>

                <div class="vm-card-modern" data-aos="fade-left" data-aos-delay="200">
                    <div class="vm-icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
                            <rect x="8" y="8" width="32" height="32" rx="4" stroke="url(#vmGradient2)" stroke-width="2"/>
                            <path d="M16 24L22 30L32 18" stroke="url(#vmGradient2)" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <h3 class="vm-title-modern">{{ __('about.beliefs.mission.label') }}</h3>
                    <div class="mission-content-modern">
                        <p class="mission-headline">
                            {{ __('about.beliefs.mission.headline') }}
                        </p>
                        <p class="mission-description">
                            {{ __('about.beliefs.mission.description') }}
                        </p>
                    </div>
                </div>
            </div>

            <svg width="0" height="0">
                <defs>
                    <linearGradient id="vmGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="#00E5FF"/>
                        <stop offset="100%" stop-color="#00B8D4"/>
                    </linearGradient>
                    <linearGradient id="vmGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="#00E5FF"/>
                        <stop offset="100%" stop-color="#00B8D4"/>
                    </linearGradient>
                </defs>
            </svg>
        </div>
    </section>

    <!-- How We Work: SBI Principles Section -->
    <section class="principles-section">
        <div class="section-container">
            <!-- Section Header -->
            <div class="section-header" data-aos="fade-up">
                <span class="section-tag-light">{{ __('about.ui.how_we_work') }}</span>
                <h2 class="section-title-light">{!! __('about.principles.title') !!}</h2>
                <p class="section-subtitle-light">
                    {{ __('about.principles.subtitle') }}
                </p>
            </div>

            <!-- Principles Grid - Interactive Cards -->
            <div class="principles-grid">
                <!-- Principle 1 -->
                <div class="principle-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="principle-card-inner">
                        <div class="principle-number">01</div>
                        <div class="principle-icon-wrapper">
                            <div class="icon-glow"></div>
                            <svg class="principle-icon" viewBox="0 0 64 64" fill="none">
                                <circle cx="32" cy="32" r="28" stroke="currentColor" stroke-width="2"/>
                                <path d="M20 32L28 40L44 24" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                                <circle cx="32" cy="32" r="20" stroke="currentColor" stroke-width="1" opacity="0.3"/>
                            </svg>
                        </div>
                        <h3 class="principle-title">{{ __('about.principles.items.0.title') }}</h3>
                        <p class="sbi-principle-description">
                            {{ __('about.principles.items.0.description') }}
                        </p>
                        <div class="principle-line"></div>
                    </div>
                </div>

                <!-- Principle 2 -->
                <div class="principle-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="principle-card-inner">
                        <div class="principle-number">02</div>
                        <div class="principle-icon-wrapper">
                            <div class="icon-glow"></div>
                            <svg class="principle-icon" viewBox="0 0 64 64" fill="none">
                                <path d="M16 48L24 32L32 40L40 24L48 32L56 16" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <circle cx="24" cy="32" r="3" fill="currentColor"/>
                                <circle cx="32" cy="40" r="3" fill="currentColor"/>
                                <circle cx="40" cy="24" r="3" fill="currentColor"/>
                                <circle cx="48" cy="32" r="3" fill="currentColor"/>
                            </svg>
                        </div>
                        <h3 class="principle-title">{{ __('about.principles.items.1.title') }}</h3>
                        <p class="sbi-principle-description">
                            {{ __('about.principles.items.1.description') }}
                        </p>
                        <div class="principle-line"></div>
                    </div>
                </div>

                <!-- Principle 3 -->
                <div class="principle-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="principle-card-inner">
                        <div class="principle-number">03</div>
                        <div class="principle-icon-wrapper">
                            <div class="icon-glow"></div>
                            <svg class="principle-icon" viewBox="0 0 64 64" fill="none">
                                <path d="M32 8V32M32 32L48 48M32 32L16 48" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <circle cx="32" cy="32" r="6" stroke="currentColor" stroke-width="2" fill="none"/>
                                <circle cx="16" cy="48" r="4" fill="currentColor"/>
                                <circle cx="48" cy="48" r="4" fill="currentColor"/>
                            </svg>
                        </div>
                        <h3 class="principle-title">{{ __('about.principles.items.2.title') }}</h3>
                        <p class="sbi-principle-description">
                            {{ __('about.principles.items.2.description') }}
                        </p>
                        <div class="principle-line"></div>
                    </div>
                </div>

                <!-- Principle 4 -->
                <div class="principle-card" data-aos="fade-up" data-aos-delay="400">
                    <div class="principle-card-inner">
                        <div class="principle-number">04</div>
                        <div class="principle-icon-wrapper">
                            <div class="icon-glow"></div>
                            <svg class="principle-icon" viewBox="0 0 64 64" fill="none">
                                <rect x="12" y="12" width="40" height="40" rx="4" stroke="currentColor" stroke-width="2"/>
                                <path d="M24 32H40M32 24V40" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
                                <circle cx="32" cy="32" r="16" stroke="currentColor" stroke-width="1" opacity="0.2"/>
                            </svg>
                        </div>
                        <h3 class="principle-title">{{ __('about.principles.items.3.title') }}</h3>
                        <p class="sbi-principle-description">
                            {{ __('about.principles.items.3.description') }}
                        </p>
                        <div class="principle-line"></div>
                    </div>
                </div>

                <!-- Principle 5 -->
                <div class="principle-card" data-aos="fade-up" data-aos-delay="500">
                    <div class="principle-card-inner">
                        <div class="principle-number">05</div>
                        <div class="principle-icon-wrapper">
                            <div class="icon-glow"></div>
                            <svg class="principle-icon" viewBox="0 0 64 64" fill="none">
                                <path d="M32 8L40 24L56 28L44 40L48 56L32 48L16 56L20 40L8 28L24 24L32 8Z" stroke="currentColor" stroke-width="2" fill="none"/>
                                <circle cx="32" cy="32" r="8" stroke="currentColor" stroke-width="1.5" opacity="0.3"/>
                            </svg>
                        </div>
                        <h3 class="principle-title">{{ __('about.principles.items.4.title') }}</h3>
                        <p class="sbi-principle-description">
                            {{ __('about.principles.items.4.description') }}
                        </p>
                        <div class="principle-line"></div>
                    </div>
                </div>
            </div>

            <!-- Decorative Elements -->
            <div class="principles-decoration">
                <div class="deco-circle deco-1"></div>
                <div class="deco-circle deco-2"></div>
                <div class="deco-line deco-line-1"></div>
                <div class="deco-line deco-line-2"></div>
            </div>
        </div>
    </section>

    <!-- Why Clients Trust Us Section -->
    <section class="testimonials-section">
        <div class="section-container">
            <div class="section-header" data-aos="fade-up">
                <span class="section-tag">{{ __('about.ui.testimonials_tag') }}</span>
                <h2 class="section-title">{!! __('about.testimonials.title') !!}</h2>
            </div>

            <div class="testimonials-slider-wrapper">
                <div class="swiper testimonials-swiper">
                    <div class="swiper-wrapper">
                        <!-- Testimonial 1 -->
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                    <div class="testimonial-quote-icon">
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                            <path d="M10 20C10 14 13 10 18 10V13C15 13 13 15 13 18H18V28H8V18H10ZM28 20C28 14 31 10 36 10V13C33 13 31 15 31 18H36V28H26V18H28Z" fill="#0284C7" opacity="0.2"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">
                        {{ __('about.testimonials.items.0.text') }}
                    </p>
                    <div class="testimonial-author">
                        <div class="author-info">
                            <h4 class="author-name">{{ __('about.testimonials.items.0.author') }}</h4>
                            <p class="author-company">{{ __('about.testimonials.items.0.company') }}</p>
                        </div>
                    </div>
                            </div>
                        </div>

                        <!-- Testimonial 2 -->
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                    <div class="testimonial-quote-icon">
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                            <path d="M10 20C10 14 13 10 18 10V13C15 13 13 15 13 18H18V28H8V18H10ZM28 20C28 14 31 10 36 10V13C33 13 31 15 31 18H36V28H26V18H28Z" fill="#0284C7" opacity="0.2"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">
                        {{ __('about.testimonials.items.1.text') }}
                    </p>
                    <div class="testimonial-author">
                        <div class="author-info">
                            <h4 class="author-name">{{ __('about.testimonials.items.1.author') }}</h4>
                            <p class="author-company">{{ __('about.testimonials.items.1.company') }}</p>
                        </div>
                    </div>
                            </div>
                        </div>

                        <!-- Testimonial 3 -->
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                    <div class="testimonial-quote-icon">
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                            <path d="M10 20C10 14 13 10 18 10V13C15 13 13 15 13 18H18V28H8V18H10ZM28 20C28 14 31 10 36 10V13C33 13 31 15 31 18H36V28H26V18H28Z" fill="#0284C7" opacity="0.2"/>
                        </svg>
                    </div>
                    <p class="testimonial-text">
                        {{ __('about.testimonials.items.2.text') }}
                    </p>
                    <div class="testimonial-author">
                        <div class="author-info">
                            <h4 class="author-name">{{ __('about.testimonials.items.2.author') }}</h4>
                            <p class="author-company">{{ __('about.testimonials.items.2.company') }}</p>
                        </div>
                    </div>
                            </div>
                        </div>

                        <!-- Testimonial 4 -->
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                                <div class="testimonial-quote-icon">
                                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                                        <path d="M10 20C10 14 13 10 18 10V13C15 13 13 15 13 18H18V28H8V18H10ZM28 20C28 14 31 10 36 10V13C33 13 31 15 31 18H36V28H26V18H28Z" fill="#0284C7" opacity="0.2"/>
                                    </svg>
                                </div>
                                <p class="testimonial-text">
                                    {{ __('about.testimonials.items.3.text') }}
                                </p>
                                <div class="testimonial-author">
                                    <div class="author-info">
                                        <h4 class="author-name">{{ __('about.testimonials.items.3.author') }}</h4>
                                        <p class="author-company">{{ __('about.testimonials.items.3.company') }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Testimonial 5 -->
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                                <div class="testimonial-quote-icon">
                                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                                        <path d="M10 20C10 14 13 10 18 10V13C15 13 13 15 13 18H18V28H8V18H10ZM28 20C28 14 31 10 36 10V13C33 13 31 15 31 18H36V28H26V18H28Z" fill="#0284C7" opacity="0.2"/>
                                    </svg>
                                </div>
                                <p class="testimonial-text">
                                    {{ __('about.testimonials.items.4.text') }}
                                </p>
                                <div class="testimonial-author">
                                    <div class="author-info">
                                        <h4 class="author-name">{{ __('about.testimonials.items.4.author') }}</h4>
                                        <p class="author-company">{{ __('about.testimonials.items.4.company') }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="swiper-pagination testimonial-pagination"></div>
                </div>
                
                <!-- Navigation outside swiper -->
                <div class="swiper-button-next testimonial-nav-next"></div>
                <div class="swiper-button-prev testimonial-nav-prev"></div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="team-section-modern">
        <div class="section-container">
            <div class="section-header" data-aos="fade-up">
                <span class="section-tag">{{ __('about.ui.leadership') }}</span>
                <h2 class="section-title">{!! __('about.ui.board_of_directors') !!}</h2>
            </div>

            <!-- Team Grid -->
            <div class="team-grid">
                <!-- Founder -->
                <div class="team-card-modern" data-aos="fade-up" data-aos-delay="100">
                    <div class="team-card-inner">
                        <div class="team-image-container">
                            <picture>
                                <source srcset="{{ asset('images/team/imelda.webp') }}" type="image/webp">
                                <source srcset="{{ asset('images/team/imelda.png') }}" type="image/png">
                                <img src="{{ asset('images/team/imelda.jpg') }}" alt="Imelda Harsono" class="team-image">
                            </picture>
                            <div class="team-overlay">
                                <div class="team-role-badge">{{ __('about.ui.founder_badge') }}</div>
                            </div>
                        </div>
                        <div class="team-content">
                            <h3 class="team-name-modern">Imelda Harsono</h3>
                            <p class="team-position">{{ __('about.ui.founder_md') }}</p>
                            <div class="team-quote-modern">
                                <svg class="quote-icon" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M6 9C6 6.8 7.8 5 10 5V7C8.9 7 8 7.9 8 9H10V15H4V9H6ZM18 9C18 6.8 19.8 5 22 5V7C20.9 7 20 7.9 20 9H22V15H16V9H18Z" fill="currentColor"/>
                                </svg>
                                <p>{{ __('about.team.imelda.quote') }}</p>
                            </div>
                            <div class="team-bio-modern">
                                <div class="bio-content">
                                    <p class="bio-preview">{{ __('about.team.imelda.bio_preview') }}</p>
                                    <div class="bio-full" style="display: none;">
                                        @foreach(__('about.team.imelda.bio_full') as $paragraph)
                                            <p>{{ $paragraph }}</p>
                                        @endforeach
                                    </div>
                                </div>
                                <button class="read-more-btn" onclick="toggleBio(this)">
                                    <span class="read-more-text">{{ __('about.ui.read_more') }}</span>
                                    <svg class="read-more-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Co-Founder -->
                <div class="team-card-modern" data-aos="fade-up" data-aos-delay="200">
                    <div class="team-card-inner">
                        <div class="team-image-container">
                            <img src="{{ asset('images/team/rachmat.webp') }}" alt="Rachmat Harsono" class="team-image">
                            <div class="team-overlay">
                                <div class="team-role-badge">{{ __('about.ui.cofounder_badge') }}</div>
                            </div>
                        </div>
                        <div class="team-content">
                            <h3 class="team-name-modern">Rachmat Harsono</h3>
                            <p class="team-position">{{ __('about.ui.cofounder_commissioner') }}</p>
                            <div class="team-quote-modern">
                                <svg class="quote-icon" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M6 9C6 6.8 7.8 5 10 5V7C8.9 7 8 7.9 8 9H10V15H4V9H6ZM18 9C18 6.8 19.8 5 22 5V7C20.9 7 20 7.9 20 9H22V15H16V9H18Z" fill="currentColor"/>
                                </svg>
                                <p>{{ __('about.team.rachmat.quote') }}</p>
                            </div>
                            <div class="team-bio-modern">
                                <div class="bio-content">
                                    <p class="bio-preview">{{ __('about.team.rachmat.bio_preview') }}</p>
                                    <div class="bio-full" style="display: none;">
                                        @foreach(__('about.team.rachmat.bio_full') as $paragraph)
                                            <p>{{ $paragraph }}</p>
                                        @endforeach
                                    </div>
                                </div>
                                <button class="read-more-btn" onclick="toggleBio(this)">
                                    <span class="read-more-text">{{ __('about.ui.read_more') }}</span>
                                    <svg class="read-more-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- COO -->
                <div class="team-card-modern" data-aos="fade-up" data-aos-delay="300">
                    <div class="team-card-inner">
                        <div class="team-image-container">
                            <img src="{{ asset('images/team/mario.jpg') }}" alt="Mario Velez" class="team-image">
                            <div class="team-overlay">
                                <div class="team-role-badge">{{ __('about.ui.coo_badge') }}</div>
                            </div>
                        </div>
                        <div class="team-content">
                            <h3 class="team-name-modern">Mario Velez</h3>
                            <p class="team-position">{{ __('about.ui.coo') }}</p>
                            <div class="team-quote-modern">
                                <svg class="quote-icon" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M6 9C6 6.8 7.8 5 10 5V7C8.9 7 8 7.9 8 9H10V15H4V9H6ZM18 9C18 6.8 19.8 5 22 5V7C20.9 7 20 7.9 20 9H22V15H16V9H18Z" fill="currentColor"/>
                                </svg>
                                <p>{{ __('about.team.mario.quote') }}</p>
                            </div>
                            <div class="team-bio-modern">
                                <div class="bio-content">
                                    <p class="bio-preview">{{ __('about.team.mario.bio_preview') }}</p>
                                    <div class="bio-full" style="display: none;">
                                        @foreach(__('about.team.mario.bio_full') as $paragraph)
                                            <p>{{ $paragraph }}</p>
                                        @endforeach
                                    </div>
                                </div>
                                <button class="read-more-btn" onclick="toggleBio(this)">
                                    <span class="read-more-text">{{ __('about.ui.read_more') }}</span>
                                    <svg class="read-more-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Let's Talk CTA Section -->
    <section class="lets-talk-section">
        <div class="lets-talk-container">
            <!-- Animated Background Elements -->
            <div class="lets-talk-bg">
                <div class="talk-gradient-orb orb-1"></div>
                <div class="talk-gradient-orb orb-2"></div>
                <div class="talk-particles"></div>
            </div>

            <div class="lets-talk-content">
                <!-- Left Side - CTA Text -->
                <div class="lets-talk-left" data-aos="fade-right">
                    <div class="talk-badge">
                        <div class="talk-badge-pulse"></div>
                        <span class="talk-badge-text">{{ __('about.cta.badge') }}</span>
                    </div>
                    
                    <h2 class="talk-heading">
                        {{ __('about.cta.title') }}
                    </h2>

                    <div class="talk-features">
                        <div class="talk-feature-item" data-aos="fade-up" data-aos-delay="100">
                            <div class="feature-check">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M16.6667 5L7.50004 14.1667L3.33337 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <span>{{ __('about.cta.features.0') }}</span>
                        </div>
                        <div class="talk-feature-item" data-aos="fade-up" data-aos-delay="150">
                            <div class="feature-check">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M16.6667 5L7.50004 14.1667L3.33337 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <span>{{ __('about.cta.features.1') }}</span>
                        </div>
                        <div class="talk-feature-item" data-aos="fade-up" data-aos-delay="200">
                            <div class="feature-check">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M16.6667 5L7.50004 14.1667L3.33337 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </div>
                            <span>{{ __('about.cta.features.2') }}</span>
                        </div>
                    </div>
                </div>

                <!-- Right Side - Form -->
                <div class="lets-talk-right" data-aos="fade-left" data-aos-delay="200">
                    <div class="talk-form-card">
                        <div class="talk-form-header">
                            <div class="form-icon-wrapper">
                                <svg class="form-icon" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                    <path d="M28 22C28 22.5304 27.7893 23.0391 27.4142 23.4142C27.0391 23.7893 26.5304 24 26 24H8L4 28V6C4 5.46957 4.21071 4.96086 4.58579 4.58579C4.96086 4.21071 5.46957 4 6 4H26C26.5304 4 27.0391 4.21071 27.4142 4.58579C27.7893 4.96086 28 5.46957 28 6V22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <div class="form-icon-glow"></div>
                            </div>
                            <h3 class="talk-form-title">{{ __('about.cta.form_title') }}</h3>
                            <p class="talk-form-subtitle">{{ __('about.cta.form_subtitle') }}</p>
                        </div>

                        <form class="talk-form" id="talkForm">
                            @csrf
                            <input type="hidden" name="source" value="about">
                            <div class="talk-form-row">
                                <div class="talk-form-group">
                                    <label for="talkFullName" class="talk-form-label">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                            <path d="M13.3333 14V12.6667C13.3333 11.9594 13.0524 11.2811 12.5523 10.781C12.0522 10.281 11.3739 10 10.6667 10H5.33333C4.62609 10 3.94781 10.281 3.44772 10.781C2.94762 11.2811 2.66667 11.9594 2.66667 12.6667V14M10.6667 4.66667C10.6667 6.13943 9.47276 7.33333 8 7.33333C6.52724 7.33333 5.33333 6.13943 5.33333 4.66667C5.33333 3.19391 6.52724 2 8 2C9.47276 2 10.6667 3.19391 10.6667 4.66667Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        {{ __('about.cta.full_name') }}
                                    </label>
                                    <input 
                                        type="text" 
                                        id="talkFullName" 
                                        name="full_name" 
                                        class="talk-form-input" 
                                        placeholder="{{ __('about.cta.placeholder_name') }}"
                                        required
                                    >
                                    <div class="talk-input-glow"></div>
                                </div>

                                <div class="talk-form-group">
                                    <label for="talkEmail" class="talk-form-label">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                            <path d="M2.66667 4L7.92667 7.50667C7.95646 7.52583 7.99023 7.53799 8.02532 7.54218C8.06042 7.54637 8.09591 7.54248 8.12933 7.53083C8.16276 7.51918 8.19324 7.50007 8.21853 7.47493C8.24382 7.44979 8.26329 7.41926 8.27556 7.38556C8.28782 7.35186 8.29258 7.31581 8.28949 7.28015C8.2864 7.24449 8.27554 7.21006 8.25763 7.17907C8.23973 7.14809 8.21523 7.12126 8.18579 7.10042C8.15635 7.07958 8.12267 7.06522 8.08733 7.05833L2.66667 4ZM2.66667 4V10.6667C2.66667 11.0203 2.80714 11.3594 3.05719 11.6095C3.30724 11.8595 3.64638 12 4 12H12C12.3536 12 12.6928 11.8595 12.9428 11.6095C13.1929 11.3594 13.3333 11.0203 13.3333 10.6667V4M2.66667 4L8 7.33333M13.3333 4L8 7.33333" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                        {{ __('about.cta.email') }}
                                    </label>
                                    <input 
                                        type="email" 
                                        id="talkEmail" 
                                        name="email" 
                                        class="talk-form-input" 
                                        placeholder="{{ __('about.cta.placeholder_email') }}"
                                        pattern="[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.(com|id|co\.id|net|org|edu|gov|mil|int|info|biz|name|museum|coop|aero|[a-z]{2})"
                                        title="Please enter a valid email address ending with .com, .id, etc."
                                        required
                                    >
                                    <div class="talk-input-glow"></div>
                                </div>
                            </div>

                            <div class="talk-form-group">
                                <label for="talkSubject" class="talk-form-label">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M14 7.33333V4.66667C14 4.31305 13.8595 3.97391 13.6095 3.72386C13.3594 3.47381 13.0203 3.33333 12.6667 3.33333H3.33333C2.97971 3.33333 2.64057 3.47381 2.39052 3.72386C2.14048 3.97391 2 4.31305 2 4.66667V11.3333C2 11.687 2.14048 12.0261 2.39052 12.2761C2.64057 12.5262 2.97971 12.6667 3.33333 12.6667H8.66667" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M2 4.66667L8 8.66667L14 4.66667M11.3333 10H14.6667M13 8.66667V11.3333" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    {{ __('about.cta.subject') }}
                                </label>
                                <input 
                                    type="text" 
                                    id="talkSubject" 
                                    name="subject" 
                                    class="talk-form-input" 
                                    placeholder="{{ __('about.cta.placeholder_subject') }}"
                                    required
                                >
                                <div class="talk-input-glow"></div>
                            </div>

                            <div class="talk-form-group">
                                <label for="talkMessage" class="talk-form-label">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M14 10C14 10.3536 13.8595 10.6928 13.6095 10.9428C13.3594 11.1929 13.0203 11.3333 12.6667 11.3333H5.33333L2 14V3.33333C2 2.97971 2.14048 2.64057 2.39052 2.39052C2.64057 2.14048 2.97971 2 3.33333 2H12.6667C13.0203 2 13.3594 2.14048 13.6095 2.39052C13.8595 2.64057 14 2.97971 14 3.33333V10Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    {{ __('about.cta.message') }}
                                </label>
                                <textarea 
                                    id="talkMessage" 
                                    name="message" 
                                    class="talk-form-textarea" 
                                    placeholder="{{ __('about.cta.placeholder_message') }}"
                                    rows="4"
                                    required
                                ></textarea>
                                <div class="talk-input-glow"></div>
                            </div>

                            <button type="submit" class="talk-submit-btn">
                                <span class="talk-btn-text">{{ __('about.cta.send_message') }}</span>
                                <div class="talk-btn-shine"></div>
                                <svg class="talk-btn-arrow" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M4.16667 10H15.8333M15.8333 10L10.8333 5M15.8333 10L10.8333 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection

@push('scripts')
<script>
function toggleBio(button) {
    const bioContent = button.previousElementSibling;
    const preview = bioContent.querySelector('.bio-preview');
    const full = bioContent.querySelector('.bio-full');
    const readMoreText = button.querySelector('.read-more-text');
    
    if (full.style.display === 'none') {
        // Expand
        preview.style.display = 'none';
        full.style.display = 'block';
        readMoreText.textContent = '{{ __('about.ui.read_less') }}';
        button.classList.add('expanded');
        
        // Smooth scroll to keep button in view if needed
        setTimeout(() => {
            const buttonRect = button.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            if (buttonRect.bottom > windowHeight) {
                button.scrollIntoView({ behavior: 'smooth', block: 'end' });
            }
        }, 100);
    } else {
        // Collapse
        preview.style.display = 'block';
        full.style.display = 'none';
        readMoreText.textContent = '{{ __('about.ui.read_more') }}';
        button.classList.remove('expanded');
    }
}

// Notification System
function showNotification(type, title, message) {
    let container = document.querySelector('.notification-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'notification-container';
        document.body.appendChild(container);
    }

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    const icons = {
        success: '<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>',
        error: '<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>',
        warning: '<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>'
    };
    
    notification.innerHTML = `
        <div class="notification-icon">${icons[type]}</div>
        <div class="notification-content">
            <div class="notification-title">${title}</div>
            <div class="notification-message">${message}</div>
        </div>
        <button class="notification-close">
            <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
        <div class="notification-progress"></div>
    `;
    
    container.appendChild(notification);
    
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => removeNotification(notification));
    
    setTimeout(() => removeNotification(notification), 5000);
}

function removeNotification(notification) {
    notification.classList.add('removing');
    setTimeout(() => {
        notification.remove();
        const container = document.querySelector('.notification-container');
        if (container && container.children.length === 0) {
            container.remove();
        }
    }, 300);
}

function isValidEmail(email) {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.(com|id|co\.id|net|org|edu|gov|mil|int|info|biz|name|museum|coop|aero|[a-z]{2})$/i;
    return emailRegex.test(email);
}

// Form submission
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('talkForm');
    const emailInput = form.querySelector('input[name="email"]');
    
    // Real-time email validation
    emailInput.addEventListener('blur', function() {
        if (this.value && !isValidEmail(this.value)) {
            this.style.borderColor = 'rgba(239, 83, 80, 0.8)';
            showNotification('error', '{{ __("about.notifications.invalid_email_title") }}', '{{ __("about.notifications.invalid_email_message") }}');
        } else if (this.value) {
            this.style.borderColor = 'rgba(56, 189, 248, 0.5)';
        }
    });
    
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const submitBtn = form.querySelector('.talk-submit-btn');
        const btnText = submitBtn.querySelector('.talk-btn-text');
        const originalText = btnText.textContent;
        
        // Validate email before submission
        const emailValue = emailInput.value;
        if (!isValidEmail(emailValue)) {
            showNotification('error', '{{ __("about.notifications.invalid_email_title") }}', '{{ __("about.notifications.invalid_email_format") }}');
            emailInput.focus();
            emailInput.style.borderColor = 'rgba(239, 83, 80, 0.8)';
            return;
        }
        
        // Disable button and show loading
        submitBtn.disabled = true;
        btnText.textContent = '{{ __("about.notifications.sending") }}';
        
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (response.ok && result.success) {
                form.reset();
                showNotification('success', '{{ __("about.notifications.message_sent_title") }}', result.message || '{{ __("about.notifications.message_sent_message") }}');
                
                // Scroll to top after successful submission
                setTimeout(() => {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }, 500);
            } else {
                let errorMessage = result.message || '{{ __("about.notifications.submission_failed_message") }}';
                if (result.errors) {
                    errorMessage = Object.values(result.errors).flat().join('. ');
                }
                showNotification('error', '{{ __("about.notifications.submission_failed_title") }}', errorMessage);
            }
        } catch (error) {
            console.error('Form submission error:', error);
            showNotification('error', '{{ __("about.notifications.connection_error_title") }}', '{{ __("about.notifications.connection_error_message") }}');
        } finally {
            submitBtn.disabled = false;
            btnText.textContent = originalText;
        }
    });
});

// About Page Slider
document.addEventListener('DOMContentLoaded', function() {
    const slider = document.querySelector('.about-slider');
    if (!slider) return;
    
    const track = slider.querySelector('.about-slider-track');
    const slides = slider.querySelectorAll('.about-slide');
    const prevBtn = document.querySelector('.about-slider-prev');
    const nextBtn = document.querySelector('.about-slider-next');
    const dotsContainer = slider.querySelector('.about-slider-dots');
    
    let currentIndex = 0;
    const totalSlides = slides.length;
    
    // Create dots
    for (let i = 0; i < totalSlides; i++) {
        const dot = document.createElement('div');
        dot.className = 'about-slider-dot';
        if (i === 0) dot.classList.add('active');
        dot.addEventListener('click', () => goToSlide(i));
        dotsContainer.appendChild(dot);
    }
    
    const dots = dotsContainer.querySelectorAll('.about-slider-dot');
    
    function updateSlider() {
        track.style.transform = `translateX(-${currentIndex * 100}%)`;
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentIndex);
        });
    }
    
    function goToSlide(index) {
        currentIndex = index;
        updateSlider();
    }
    
    function nextSlide() {
        currentIndex = (currentIndex + 1) % totalSlides;
        updateSlider();
    }
    
    function prevSlide() {
        currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
        updateSlider();
    }
    
    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);
    
    // Auto-play (optional - uncomment to enable)
    // setInterval(nextSlide, 5000);
});

// Initialize Testimonials Swiper
if (document.querySelector('.testimonials-swiper')) {
    new Swiper('.testimonials-swiper', {
        slidesPerView: 1,
        spaceBetween: 40,
        loop: true,
        autoHeight: false,
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.testimonial-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.testimonial-nav-next',
            prevEl: '.testimonial-nav-prev',
        },
        breakpoints: {
            640: {
                slidesPerView: 1,
                spaceBetween: 30,
            },
            768: {
                slidesPerView: 1,
                spaceBetween: 40,
            },
            1024: {
                slidesPerView: 2,
                spaceBetween: 40,
            },
        },
    });
}
</script>
@endpush
