# Team Member Images

Placeholder images for team members mentioned in testimonials:

- fiona.jpg - Fiona Gabriela (Business Intelligence Analyst)
- prilya.jpg - Prilya Angel (Business Intelligence Analyst)  
- kevin.jpg - Kevin Wijaya (Business Intelligence Analyst)

Note: These should match the team members from the about page if they're the same people.

Recommended: 400x400px, square format, professional headshots
