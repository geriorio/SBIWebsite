# Career Images

Placeholder images for career section. Replace with actual images:

- business-analyst.jpg - Image representing Business Intelligence Analyst role
- internship.jpg - Image representing Business Analyst Internship role

Recommended dimensions: 1000x600px
Format: JPG or WebP for better performance
